#ifndef HERO_H_INCLUDED
#define HERO_H_INCLUDED

void Hero_Init(Hero *obj, float x1, float y1, float dx1, float dy1);
void Hero_Move(Hero *obj);

#endif // HERO_H_INCLUDED
